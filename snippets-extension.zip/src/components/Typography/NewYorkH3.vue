<script setup lang="ts">
// This component just wraps its content with your typography classes.
// Adjust the classes based on your New York theme configuration.
</script>

<template>
  <div class="scroll-m-20 text-xl font-semibold tracking-tight">
    <slot />
  </div>
</template>