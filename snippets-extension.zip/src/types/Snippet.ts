export interface Snippet {
  name: string,
  text: string,
  shortcut: string
}